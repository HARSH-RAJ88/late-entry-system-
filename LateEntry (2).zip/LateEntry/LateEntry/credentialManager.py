class CredentialManager:
    host = "localhost"
    user = "root"
    password = "jain@22b"
    database = "Late_entry_system"
